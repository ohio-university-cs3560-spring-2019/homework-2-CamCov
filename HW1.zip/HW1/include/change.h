/***************************************************
Author: Cameron Coventry	Date: 1/29/19

Current file: change.h

****************************************************
#include <iostream>
#include <cstdlib>
using namespace std;

/**************************
Function: StringChange

Purpose: Function declaration for StringChange
**************************/

void StringChange(char** argv);
