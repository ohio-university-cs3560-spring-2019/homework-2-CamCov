
/***************************************************
Author: Cameron Coventry	Date: 1/29/19

Program files: change.cc, change.h, input1.txt makefile

Purpose: To Swap a string input for a command line argument
          with another stirng input as a command line argument

Current file: main.cc

****************************************************
#include <iostream>
#include <cstdlib>
#include "change.h"
using namespace std;




int main(int argc, char** argv)
{

StringChange(argv);

return(0);
}
